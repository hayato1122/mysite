class BooksController < ApplicationController
  def new
    @books = Book.new
  end
  def create
    @books = Books.new(list_params)
    if @books.save
      redirect_to todolist_path(@books.id)
    else
      redirect_to todolists_new_path
    end
  end
  def index
    @books = Book.all
    p @books
    p "標準出力にのみ反映"
    logger.debug("標準出力とログファイルに記録される")

  end
  def show
    @books = Book.find(params[:id])
  end

  def edit
    @books = Book.find(params[:id])
  end
  def books
     books = Book.find(params[:id])
    books.update(books_params)
    redirect_to books_path(list.id)
  end
  def destroy
    books = Books.find(params[:id])
    books.destroy
    redirect_to books_path
  end
  private
  def books_params
    params.require(:books).permit(:title, :body)
  end
end