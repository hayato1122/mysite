class Migrate < ApplicationRecord
end
