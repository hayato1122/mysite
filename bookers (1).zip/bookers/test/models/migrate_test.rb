require 'test_helper'

class MigrateTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
